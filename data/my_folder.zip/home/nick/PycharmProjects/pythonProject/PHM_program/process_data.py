import os
import pandas as pd
import time
import numpy as np

path = "/home/nick/PycharmProjects/pythonProject/data"

# 紀錄每個data set中最長的序列值長度
p1 = {"DATA_C":0, "REF_C":0}
p2 = {"DATA_C":0, "REF_C":0}
p3 = {"DATA_C":0, "REF_C":0}
p4 = {"DATA_C":0, "REF_C":0}
p5 = {"DATA_C":0, "REF_C":0}
p6 = {"DATA_C":0, "REF_C":0}
person = [p1, p2, p3, p4, p5, p6]
max_SequenceNum = 0

data_interpolated = pd.DataFrame()
def read_data():
    global max_SequenceNum
    for person_num, dict in enumerate(os.listdir(path)):
        file_path = os.path.join(path, dict)

        for file in os.listdir(file_path):
            t = time.time()
            data = pd.read_csv(os.path.join(file_path, file))
            if ("data_pdmp" in file):
                person[int(dict)-1]["DATA_C"] = len(data.columns)
            elif ("ref_pdmp" in file):
                person[int(dict)-1]["REF_C"] = len(data.columns)
            person[int(dict)-1][file] = data
            print(time.time() - t, " , read data done!")
        max_SequenceNum = max(person[int(dict) - 1]["DATA_C"], person[int(dict) - 1]["REF_C"], max_SequenceNum)

def interpolate_sequence(sequence, target_length):
    averages = (sequence[1:-1] + sequence[2:]) / 2
    num_to_insert = min(target_length - len(sequence), len(averages))
    selected_averages = averages[:num_to_insert]
    for i, avg in enumerate(selected_averages):
        insert_position = 2 * i + 2
        sequence = np.insert(sequence, insert_position, avg)
    return sequence

def interpolation_data():
    for p in person:
        for data_name in list(p.keys())[2:]:
            p_data = p[data_name]
            data_interpolated = p_data.apply(lambda row: interpolate_sequence(np.array(row), max_SequenceNum), axis=1).apply(pd.Series)
            data_interpolated.to_csv(os.path.join("/home/nick/PycharmProjects/pythonProject/interpolated", data_name), index=False)


def process_data():
    # 讀取data，並用內插法填值
    read_data()
    interpolation_data()



print("done")
