import os
import pandas as pd
import numpy as np
from scipy.fft import fft

path = "/home/nick/PycharmProjects/pythonProject/interpolated"

def read_data(file_path):
    return pd.read_csv(file_path)

def cread_dateframe():
    pf_data = pd.DataFrame(columns=["Target"] + ["fft_" + str(i) for i in range(50)])
    return pf_data

def data_fft():
    window_size = 50  # 滑動視窗大小
    step = 30  # 步長

    for file in os.listdir(path):
        data = read_data(os.path.join(path, file))
        pf_data = cread_dateframe()
        pf_data['Target'] = data["0"]
        for index, row in data.iterrows():
            for num, i in enumerate(range(0, len(row) - window_size + 1, step)):
                window_data = row.values[i:i + window_size]

                # 如果視窗結尾超出序列長度，只取序列中剩餘的部分
                if i + window_size > len(row):
                    window_data = row.values[i:]

                # 針對每筆資料並根據視窗大小及步長做傅立葉轉換，並取振幅加總
                fft_result = fft(window_data)
                amplitude = np.abs(fft_result) ** 2
                pf_data.iloc[index, num+1] = np.sum(amplitude)
                print("Window Data:", window_data)
                print("FFT Result:", np.sum(amplitude))

data_fft()
